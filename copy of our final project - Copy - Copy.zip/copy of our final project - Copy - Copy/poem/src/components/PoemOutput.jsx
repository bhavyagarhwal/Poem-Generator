// // // // import React from "react";
// // // // import styles from "./PoemOutput.module.css";

// // // // const PoemOutput = () => {
// // // //   return (
// // // //     <div className={styles.poemBox}>
// // // //       <h2>Your Generated Poem:</h2>
// // // //       <p className={styles.poemText}>
// // // //         [Your generated poem will appear here...]
// // // //       </p>
// // // //     </div>
// // // //   );
// // // // };

// // // // export default PoemOutput;

// // // import React from "react";
// // // import styles from "./PoemOutput.module.css";

// // // const PoemOutput = ({ poem }) => {
// // //   return (
// // //     <div className={styles.poemBox}>
// // //       <h2>Your Generated Poem:</h2>
// // //       <p className={styles.poemText}>
// // //         {poem || "[Your generated poem will appear here...]"}
// // //       </p>
// // //     </div>
// // //   );
// // // };

// // // export default PoemOutput;

// // import React from "react";
// // import styles from "./PoemOutput.module.css";

// // const PoemOutput = ({ poem }) => {
// //   return (
// //     <div className={styles.poemBox}>
// //       <h2>Your Generated Poem:</h2>
// //       <p
// //         className={styles.poemText}
// //         dangerouslySetInnerHTML={{
// //           __html: poem || "[Your generated poem will appear here...]",
// //         }}
// //       />
// //     </div>
// //   );
// // };

// // export default PoemOutput;

// import React from "react";
// import styles from "./PoemOutput.module.css";

// const PoemOutput = ({ title, poem }) => {
//   return (
//     <div className={styles.poemBox}>
//       <h2>{title || "Your Generated Poem Title"}</h2>
//       <p className={styles.poemText}>
//         {poem || "[Your generated poem will appear here...]"}
//       </p>
//     </div>
//   );
// };

// export default PoemOutput;
import React from "react";
import styles from "./PoemOutput.module.css";

const PoemOutput = ({ poemData }) => {
  const { title, poem } = poemData;

  return (
    <div className={styles.poemBox}>
      <h2>{title || "Your Generated Poem Title"}</h2>
      <p className={styles.poemText}>{poem}</p>
    </div>
  );
};

export default PoemOutput;
